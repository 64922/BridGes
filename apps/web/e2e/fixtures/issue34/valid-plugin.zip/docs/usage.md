# 用法
见 [README](../SKILL.md)。
