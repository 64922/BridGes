---
plugin_id: e2e-todo
name: 待办整理助手
version: 1.2.3
description: 把聊天中的待办整理成清单的声明式 SKILL（E2E 夹具）。
source: 测试用户
license: 仅供测试使用
capabilities:
  - 提取待办事项
  - 输出清单
data_categories:
  - 用户粘贴的待办文本
---

# 待办整理助手

把文本中的待办事项整理成清单。

参见 [说明文档](docs/usage.md) 与模板 [templates/checklist.html](templates/checklist.html)。
